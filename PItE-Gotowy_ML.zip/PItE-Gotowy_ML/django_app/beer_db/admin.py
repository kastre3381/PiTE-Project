from django.contrib import admin
from .models import Beer
# Register your models here.
"""@package docstring
More Details.
"""
admin.site.register(Beer)