from django.apps import AppConfig


class PredictBeerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'predict_beer'
