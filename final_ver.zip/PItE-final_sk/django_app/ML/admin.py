from django.contrib import admin
from ML.models import RatingModel
# Register your models here.

admin.site.register(RatingModel)
